(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/bootstrap.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
Meteor.startup(function () {                                           // 2
                                                                       //
  /*                                                                   //
  	//populate necessary collections                                    //
  	for (var i = 0; i < activityTypes.length; i++) {                    //
  	                                                                    //
   	ActivityTypes.insert({                                             //
   		activityId: i,                                                    //
   		activityTypeName: activityTypes[i]                                //
   	});                                                                //
  	                                                                    //
  	};*/                                                                //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=bootstrap.js.map
