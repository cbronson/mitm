(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
                                                                       //
	createNewLink: function (UID) {                                       // 3
		var linkId = Links.insert({                                          // 4
			ownerUID: UID,                                                      // 6
			step: 1,                                                            // 7
			createdAt: Date.now()                                               // 8
		});                                                                  //
		console.log(linkId);                                                 // 10
		return linkId;                                                       // 11
	},                                                                    //
                                                                       //
	updateLinkStep: function (LID, s) {                                   // 14
		Links.update(LID, {                                                  // 15
			$set: { step: s }                                                   // 16
		});                                                                  //
	},                                                                    //
                                                                       //
	addLinkAddress: function (LID, addressNum, addressCoords) {           // 20
		if (addressNum == 1) {                                               // 21
			Links.update(LID, {                                                 // 22
				$set: { addressOneCoords: addressCoords }                          // 23
			});                                                                 //
		}                                                                    //
                                                                       //
		if (addressNum == 2) {                                               // 27
			Links.update(LID, {                                                 // 28
				$set: { addressTwoCoords: addressCoords }                          // 29
			});                                                                 //
		}                                                                    //
                                                                       //
		//midpoint address                                                   //
		if (addressNum == 3) {                                               // 34
			Links.update(LID, {                                                 // 35
				$set: { midPointCoords: addressCoords }                            // 36
			});                                                                 //
		}                                                                    //
	},                                                                    //
                                                                       //
	addMeetingPlaces: function (LID, placeObject) {                       // 41
		console.log("MEETING PLACES ADDED");                                 // 42
		MeetingPlaces.insert({                                               // 43
			LID: LID,                                                           // 44
			placeName: placeObject.name,                                        // 45
			placeVicinity: placeObject.vicinity,                                // 46
			placeLat: placeObject.lat,                                          // 47
			placeLng: placeObject.lng                                           // 48
		});                                                                  //
	},                                                                    //
                                                                       //
	calcMidPoint: function (LID) {                                        // 52
		var coordsOne = Links.findOne({ _id: LID }).addressOneCoords;        // 53
		var coordsTwo = Links.findOne({ _id: LID }).addressTwoCoords;        // 54
                                                                       //
		// Converts from degrees to radians.                                 //
		radians = function (degrees) {                                       // 57
			return degrees * Math.PI / 180;                                     // 58
		};                                                                   //
                                                                       //
		degrees = function (radians) {                                       // 61
			return radians * 180 / Math.PI;                                     // 62
		};                                                                   //
                                                                       //
		var coordsLat1 = radians(coordsOne.lat);                             // 65
		var coordsLng1 = radians(coordsOne.lng);                             // 66
                                                                       //
		var coordsLat2 = radians(coordsTwo.lat);                             // 68
		var coordsLng2 = radians(coordsTwo.lng);                             // 69
                                                                       //
		//find midpoint between coordinates                                  //
		var Bx = Math.cos(coordsLat2) * Math.cos(coordsLng2 - coordsLng1);   // 73
		var By = Math.cos(coordsLat2) * Math.sin(coordsLng2 - coordsLng1);   // 74
		var mpLat = Math.atan2(Math.sin(coordsLat1) + Math.sin(coordsLat2), Math.sqrt((Math.cos(coordsLat1) + Bx) * (Math.cos(coordsLat1) + Bx) + By * By));
		var mpLng = coordsLng1 + Math.atan2(By, Math.cos(coordsLat1) + Bx);  // 77
		mpLng = (mpLng + 3 * Math.PI) % (2 * Math.PI) - Math.PI; // normalise to -180..+180°
                                                                       //
		var mp = { "lat": degrees(mpLat), "lng": degrees(mpLng) };           // 80
		return mp;                                                           // 81
	}                                                                     //
                                                                       //
});                                                                    //
                                                                       //
Meteor.startup(function () {});                                        // 86
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.js.map
